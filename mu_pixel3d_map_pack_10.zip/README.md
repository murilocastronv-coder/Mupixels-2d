# MU-inspired Pixel 3D — Map Pack (10 maps)

Protótipo original de mapas para MMORPG de navegador, inspirado no clima de fantasia de MU Online, sem reutilizar mapas, texturas ou modelos proprietários do jogo original.

## Incluído
- 10 biomas/mapas gerados proceduralmente em Three.js: Lorencia-inspired, Noria-inspired, Dungeon, Devias-inspired, Lost Tower-inspired, Atlans-inspired, Tarkan-inspired, Aida-inspired, Icarus-inspired e Kalima-inspired.
- Texturas pixeladas geradas por código no navegador.
- Terreno em tiles, caminhos, casas, árvores, rochas, cristais e pilares.
- Personagem placeholder para testar movimento local.
- Câmera isométrica, rotação por arrasto, zoom, controles WASD/setas.
- Layout responsivo para celular e PC; adapta proporção, resolução e painel de interface.
- Sem backend: este ZIP é um protótipo visual local, ainda não contém multiplayer, contas ou salvamento de personagem.

## Testar localmente
É necessário servir os arquivos por HTTP (módulos ES do navegador não funcionam de forma consistente via `file://`).

Com Python instalado:
```bash
python -m http.server 8080
```
Abra `http://localhost:8080`.

## Publicar no Render (site estático)
1. Envie o conteúdo deste ZIP para um repositório GitHub.
2. No Render, escolha **New + > Static Site** e conecte o repositório.
3. Build Command: deixe vazio.
4. Publish Directory: `.` (raiz do repositório).
5. Faça o deploy. O Three.js é carregado pelo CDN jsDelivr, então o navegador precisa de conexão à internet.

O `render.yaml` incluído fornece uma configuração de Static Site como referência.

## Estrutura
- `index.html` — interface
- `style.css` — layout responsivo
- `src/main.js` — cena Three.js, mapas procedurais, controles e assets
- `render.yaml` — configuração de deploy estático

## Próximos passos para produção
Trocar placeholders por sprites/modelos originais de alta qualidade, separar cada mapa em arquivos de dados, adicionar colisões, monstros, drops, combate, servidor autoritativo e banco de dados para multiplayer real.
