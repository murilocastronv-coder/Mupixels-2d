import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const maps = [
 {name:'Lorencia — Vale dos Heróis',desc:'Pradarias verdes, trilhas de pedra e ruínas de uma cidade medieval.',ground:0x527b43,accent:0xb8a078,kind:'town'},
 {name:'Noria — Floresta Élfica',desc:'Bosque luminoso, cogumelos, árvores antigas e clareiras élficas.',ground:0x3f7950,accent:0x91b86b,kind:'forest'},
 {name:'Dungeon — Cripta Esquecida',desc:'Pedra escura, pilares partidos e corredores de uma cripta antiga.',ground:0x55545a,accent:0x8e6e5a,kind:'dungeon'},
 {name:'Devias — Fronteira Gelada',desc:'Neve azulada, pinheiros cobertos de gelo e rochas congeladas.',ground:0xb5cbd0,accent:0x7799ad,kind:'snow'},
 {name:'Lost Tower — Torre Perdida',desc:'Planícies sombrias e fragmentos de uma torre arcana.',ground:0x625d70,accent:0xb3a2c9,kind:'tower'},
 {name:'Atlans — Ruínas Submersas',desc:'Leito oceânico, corais e colunas de uma civilização submersa.',ground:0x287b8c,accent:0x58c4bd,kind:'water'},
 {name:'Tarkan — Deserto de Cinzas',desc:'Dunas quadriculadas, rochas avermelhadas e ossadas antigas.',ground:0xb98a53,accent:0xe2bd79,kind:'desert'},
 {name:'Aida — Selva Antiga',desc:'Vegetação densa, árvores gigantes e pedras cobertas de musgo.',ground:0x355c3c,accent:0x72924d,kind:'jungle'},
 {name:'Icarus — Planalto Celeste',desc:'Ilhas suspensas, cristais e caminhos nas alturas.',ground:0x8c9aa8,accent:0xd6c98e,kind:'sky'},
 {name:'Kalima — Abismo Espectral',desc:'Terras corrompidas, cristais mágicos e fendas de energia.',ground:0x433b65,accent:0x9d77c9,kind:'arcane'}
];
const canvas=document.querySelector('#scene');
const renderer=new THREE.WebGLRenderer({canvas,antialias:false,alpha:false});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.15;
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x9bb5c2);
scene.fog=new THREE.Fog(0x9bb5c2,24,58);
const camera=new THREE.OrthographicCamera(-15,15,10,-10,.1,150);
camera.position.set(18,22,18); camera.lookAt(0,0,0);
scene.add(new THREE.HemisphereLight(0xd8e9ff,0x3c352b,2.1));
const sun=new THREE.DirectionalLight(0xffe6bd,3.1); sun.position.set(-12,25,10); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);
const world=new THREE.Group(); scene.add(world);
let active=0, dragging=false, lastX=0,lastY=0, yaw=Math.PI/4, zoom=1, player;
const keys={};
const select=document.querySelector('#mapSelect');
maps.forEach((m,i)=>{const o=document.createElement('option');o.value=i;o.textContent=m.name;select.appendChild(o)});
function seeded(seed){let x=seed|0;return ()=>{x=(x*1664525+1013904223)|0;return (x>>>0)/4294967296}}
function pixelTexture(base, speckle, seed=1){
 const size=128,c=document.createElement('canvas');c.width=c.height=size;const ctx=c.getContext('2d');ctx.fillStyle='#'+base.toString(16).padStart(6,'0');ctx.fillRect(0,0,size,size);const rnd=seeded(seed);
 for(let i=0;i<650;i++){let x=(rnd()*size)|0,y=(rnd()*size)|0,w=2+((rnd()*8)|0);ctx.globalAlpha=.12+rnd()*.25;ctx.fillStyle='#'+speckle.toString(16).padStart(6,'0');ctx.fillRect(x,y,w,2+((rnd()*5)|0))}
 ctx.globalAlpha=1;const t=new THREE.CanvasTexture(c);t.magFilter=THREE.NearestFilter;t.minFilter=THREE.NearestMipmapNearestFilter;t.colorSpace=THREE.SRGBColorSpace;return t;
}
function mat(color,seed=1,speckle=null){return new THREE.MeshStandardMaterial({color,map:speckle?pixelTexture(color,speckle,seed):null,roughness:1,flatShading:true})}
function box(parent,x,y,z,sx,sy,sz,material){const o=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),material);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o}
function tree(parent,x,z,rnd,kind){const trunk=mat(kind==='snow'?0x65503d:0x5b3928,2,0x9b7650), leaves=mat(kind==='snow'?0x7ca5b6:kind==='jungle'?0x1e4930:kind==='forest'?0x4f8a4b:0x3e6c3a,3,0x91a95a);
 box(parent,x,.55,z,.28,1.1,.28,trunk);
 for(let i=0;i<3;i++){const g=new THREE.Mesh(new THREE.ConeGeometry(.95-i*.18,1.15,5),leaves);g.position.set(x,.95+i*.52,z);g.rotation.y=.4;g.castShadow=true;parent.add(g)}
}
function rock(parent,x,z,rnd,color){const m=new THREE.Mesh(new THREE.DodecahedronGeometry(.35+rnd()*.5,0),mat(color,Math.floor(rnd()*999),0x8e8e8e));m.position.set(x,.25,z);m.scale.y=.7;m.rotation.set(rnd(),rnd(),rnd());m.castShadow=true;parent.add(m)}
function building(parent,x,z,seed,accent){const stone=mat(0x8a8174,seed,accent),roof=mat(accent,seed+1,0x554b45);box(parent,x,.8,z,2.1,1.6,1.8,stone);box(parent,x,1.85,z,2.35,.35,2.05,roof);box(parent,x,.45,z+.93,.42,.9,.08,mat(0x382b25));}
function crystal(parent,x,z,color,rnd){const m=new THREE.Mesh(new THREE.OctahedronGeometry(.55+rnd()*.45,0),new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.25,flatShading:true,roughness:.4}));m.position.set(x,.75,z);m.scale.y=1.7;m.rotation.y=rnd()*2;m.castShadow=true;parent.add(m)}
function makePlayer(){const g=new THREE.Group();const body=mat(0x385c91,1,0x9cb6dc),skin=mat(0xd8ad83),metal=mat(0xc8c8b9);box(g,0,.75,0,.45,.7,.3,body);box(g,0,1.28,0,.34,.34,.34,skin);box(g,-.14,.27,0,.16,.5,.2,metal);box(g,.14,.27,0,.16,.5,.2,metal);box(g,.34,.72,0,.13,.48,.13,metal);g.position.set(0,0,0);world.add(g);return g}
function buildMap(index){
 active=index;const data=maps[index];while(world.children.length)world.remove(world.children[0]);
 scene.background=new THREE.Color(data.kind==='snow'?0xa8c7d8:data.kind==='dungeon'||data.kind==='arcane'?0x25283b:data.kind==='desert'?0xd7b37b:data.kind==='water'?0x276e87:0x9bb5c2);
 scene.fog.color.copy(scene.background);scene.fog.near=25;scene.fog.far=62;
 const rnd=seeded(400+index*997);
 const groundMat=mat(data.ground,100+index,data.accent);
 const ground= new THREE.Mesh(new THREE.PlaneGeometry(38,38),groundMat);ground.rotation.x=-Math.PI/2;ground.position.y=-.08;ground.receiveShadow=true;world.add(ground);
 // Chunked tile grid gives a crisp pixel/isometric floor.
 const tileMat=mat(data.ground,200+index,data.accent);
 for(let x=-9;x<10;x++)for(let z=-9;z<10;z++){if(rnd()>.22){const tile=box(world,x*1.8,-.015,z*1.8,1.76,.035,1.76,tileMat);tile.receiveShadow=true}}
 // stone path
 const pathMat=mat(data.kind==='snow'?0x879da6:data.kind==='desert'?0xd9b578:data.kind==='dungeon'?0x373740:0x9a927f,400+index,0xc6bba3);
 for(let i=-7;i<=7;i++){const t=box(world,i*1.8,.015,0,1.5,.06,1.5,pathMat);t.rotation.y=(i%2)*.08}
 // landmarks and biome props
 for(let i=0;i<45;i++){
  let x=(rnd()-.5)*31,z=(rnd()-.5)*31;if(Math.abs(z)<2.5)continue;
  if(data.kind==='town'&&rnd()<.15)building(world,x,z,i,data.accent);
  else if(['forest','jungle','snow'].includes(data.kind)&&rnd()<.72)tree(world,x,z,rnd,data.kind);
  else if(data.kind==='arcane'||data.kind==='sky'||(data.kind==='water'&&rnd()<.5))crystal(world,x,z,data.kind==='arcane'?0x9e65e9:data.kind==='water'?0x43e4d2:0xe2d69c,rnd);
  else if(data.kind==='tower'&&rnd()<.35){box(world,x,.9,z,.6,1.8,.6,mat(0x51475d,8,0x8b7aa3));box(world,x,1.9,z,.9,.18,.9,mat(data.accent))}
  else rock(world,x,z,rnd,data.kind==='snow'?0x829ba6:data.kind==='desert'?0x8f6646:data.kind==='water'?0x247c87:data.kind==='dungeon'?0x45434b:0x655f68);
 }
 if(data.kind==='town'){building(world,-4,3,4,data.accent);building(world,4,-4,5,data.accent)}
 if(data.kind==='dungeon'||data.kind==='tower'){for(let x=-6;x<=6;x+=3){box(world,x,1.5,-5,.6,3,.6,mat(0x4a4851,2,0x827c87));box(world,x,3.1,-5,1,.25,1,mat(data.accent))}}
 player=makePlayer();
 document.querySelector('#mapDescription').textContent=data.desc;
 document.querySelector('#loading').classList.add('hidden');
}
select.addEventListener('change',()=>buildMap(Number(select.value)));
document.querySelector('#resetCamera').addEventListener('click',()=>{yaw=Math.PI/4;zoom=1;camera.position.set(18,22,18);camera.lookAt(0,0,0)});
canvas.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener('pointermove',e=>{if(!dragging)return;yaw+=(e.clientX-lastX)*.008;lastX=e.clientX;lastY=e.clientY});
canvas.addEventListener('pointerup',()=>dragging=false);canvas.addEventListener('pointercancel',()=>dragging=false);
canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.65,Math.min(1.8,zoom+e.deltaY*.001));},{passive:false});
canvas.addEventListener('touchmove',e=>{if(e.touches.length===2){const dx=e.touches[0].clientX-e.touches[1].clientX;zoom=Math.max(.65,Math.min(1.8,zoom+dx*.00002));}},{passive:true});
window.addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
function resize(){const w=window.innerWidth,h=window.innerHeight,aspect=w/h;const span=10/zoom;camera.left=-span*aspect;camera.right=span*aspect;camera.top=span;camera.bottom=-span;camera.updateProjectionMatrix();renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));renderer.setSize(w,h)}
window.addEventListener('resize',resize);resize();buildMap(0);
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);if(player){let dx=0,dz=0;if(keys.w||keys.arrowup)dz-=1;if(keys.s||keys.arrowdown)dz+=1;if(keys.a||keys.arrowleft)dx-=1;if(keys.d||keys.arrowright)dx+=1;if(dx||dz){const len=Math.hypot(dx,dz);dx/=len;dz/=len;player.position.x+=dx*dt*4;player.position.z+=dz*dt*4;player.rotation.y=Math.atan2(dx,dz)}}const r=28;camera.position.set(Math.sin(yaw)*r,22,Math.cos(yaw)*r);camera.position.multiplyScalar(1/zoom);camera.lookAt(player?player.position.x:0,0,player?player.position.z:0);renderer.render(scene,camera)}
animate();
